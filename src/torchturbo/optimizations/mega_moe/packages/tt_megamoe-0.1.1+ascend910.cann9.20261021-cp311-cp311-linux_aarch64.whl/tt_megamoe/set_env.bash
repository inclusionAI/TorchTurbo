_tt_moe_package_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export ASCEND_CUSTOM_OPP_PATH="$_tt_moe_package_dir/lib/vendors/hyper_parallel_multicore_nn:${ASCEND_CUSTOM_OPP_PATH:-}"
export LD_LIBRARY_PATH="$_tt_moe_package_dir/lib/vendors/hyper_parallel_multicore_nn/op_api/lib:$_tt_moe_package_dir/shmem/lib:$_tt_moe_package_dir/shmem/lib/shmem:${LD_LIBRARY_PATH:-}"
unset _tt_moe_package_dir
