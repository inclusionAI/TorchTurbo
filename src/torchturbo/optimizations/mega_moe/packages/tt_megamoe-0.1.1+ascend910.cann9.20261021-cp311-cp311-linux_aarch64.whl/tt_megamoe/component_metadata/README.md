# Standalone Ascend MegaMoE component

This directory contains the independent Python runtime, native operator sources,
and the tested native payload. No HyperParallel Python package is imported.
Existing native vendor and operator names are retained for ABI compatibility.

The supported prebuilt environment is Linux aarch64, Python 3.11, PyTorch 2.10.0,
torch_npu 2.10.0.post2, CANN 9.0.0 and Ascend 910_93. Other binary combinations
require a matching native build and rerunning the device acceptance tests.

The normal Swift entry point activates the component automatically only when
`engine_config.mega_moe: true` is present in the YAML. Direct native tests source
`component/set_env.bash` after the CANN environment. Sourcing this script does
not change the model backend by itself.

- `tt_megamoe/`: runtime and relocatable native payload.
- `native/`: the operator and scheduler sources corresponding to this payload.
- `manifest.json`, `payload_manifest.json`, `relocation_manifest.json`: provenance.
- `LICENSE`: component license; retained source files carry upstream notices.

The native code implements no clipping, clipping before SiLU, and clipping after
SiLU as distinct modes. The integration selects the model-configured mode.
Device acceptance tests compare outputs and all input/weight gradients against
an independent implementation, including clipping boundaries and checkpointing.
The hardware performance gate is separate from those precision checks.
