"""Activate this component's native loader paths before importing Torch."""
import os
from pathlib import Path
import sys


def activate() -> bool:
    package = Path(__file__).resolve().parent
    vendor = package / "lib/vendors/hyper_parallel_multicore_nn"
    if not vendor.is_dir():
        raise RuntimeError(f"MegaMoE native payload is missing: {vendor}")
    paths = {
        "ASCEND_CUSTOM_OPP_PATH": [vendor],
        "LD_LIBRARY_PATH": [vendor / "op_api/lib", package / "shmem/lib",
                            package / "shmem/lib/shmem"],
    }
    missing = {}
    for variable, entries in paths.items():
        current = os.environ.get(variable, "")
        registered = {Path(value).resolve() for value in current.split(os.pathsep) if value}
        pending = [str(path) for path in entries if path.resolve() not in registered]
        if pending:
            missing[variable] = os.pathsep.join([*pending, current]).rstrip(os.pathsep)
    if not missing:
        return True
    os.environ.update(missing)
    # The dynamic loader reads LD_LIBRARY_PATH when the process starts.
    os.execv(sys.executable, [sys.executable, *sys.argv])
    return True
