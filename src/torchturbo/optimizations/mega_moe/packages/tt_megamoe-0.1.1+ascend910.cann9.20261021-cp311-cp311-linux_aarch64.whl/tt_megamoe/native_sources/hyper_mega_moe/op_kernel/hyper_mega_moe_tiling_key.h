/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/* !
 * \file hyper_mega_moe_tiling_key.h
 * \brief
 */

#ifndef HYPER_MEGA_MOE_TILING_KEY_H
#define HYPER_MEGA_MOE_TILING_KEY_H

#include "ascendc/host_api/tiling/template_argument.h"

// Datatype definition reference to DT_***
#define GMM_TPL_INVALID 0xFFFFFFFF
#define GMM_TPL_FLOAT 0
#define GMM_TPL_FLOAT16 1
#define GMM_TPL_INT8 2
#define GMM_TPL_INT32 3
#define GMM_TPL_BF16 27
#define GMM_TPL_INT4 29

#define GROUPED_MATMUL_GROUP_LIST_TYPE_CUMSUM 0
#define GROUPED_MATMUL_GROUP_LIST_TYPE_COUNT 1
#define GROUPED_MATMUL_GROUP_LIST_TYPE_SPARSEM 2

#define GROUPED_MATMUL_A8W4_KERNEL_TEMPLATE_NONE 0
#define GROUPED_MATMUL_A8W4_KERNEL_TEMPLATE_MSD_API_DEQUANT 1
#define GROUPED_MATMUL_A8W4_KERNEL_TEMPLATE_MSD_VECTOR_DEQUANT 2
#define GROUPED_MATMUL_A8W4_KERNEL_TEMPLATE_PERCHANNEL_ANTIQUANT 3
#define GROUPED_MATMUL_A8W4_KERNEL_TEMPLATE_PERGROUP_ANTIQUANT 4
#define GROUPED_MATMUL_A8W4_KERNEL_TEMPLATE_AUTOTILING 5

#define GROUPED_MATMUL_A16W8_KERNEL_TEMPLATE_NONE 0
#define GROUPED_MATMUL_A16W8_KERNEL_TEMPLATE_MSD 1
#define GROUPED_MATMUL_A16W8_KERNEL_TEMPLATE_ANTIQUANT 2

#define GROUPED_MATMUL_CUBE_ONLY 0
#define GROUPED_MATMUL_AIV_AIC_RATIO_1 1
#define GROUPED_MATMUL_AIV_AIC_RATIO_2 2

#define SET_GMM_NO_QUANT_TPL_ARGS(kernel_type, dtype, trans_a, trans_b, aiv_aic_ratio)                                \
  ASCENDC_TPL_KERNEL_TYPE_SEL(kernel_type), ASCENDC_TPL_DTYPE_SEL(D_T_A, dtype), ASCENDC_TPL_DTYPE_SEL(D_T_B, dtype), \
    ASCENDC_TPL_DTYPE_SEL(D_T_Y, dtype), ASCENDC_TPL_BOOL_SEL(TRANS_A, trans_a),                                      \
    ASCENDC_TPL_BOOL_SEL(TRANS_B, trans_b),                                                                           \
    ASCENDC_TPL_UINT_SEL(GROUP_LIST_TYPE, ASCENDC_TPL_UI_LIST, GROUPED_MATMUL_GROUP_LIST_TYPE_CUMSUM,                 \
                         GROUPED_MATMUL_GROUP_LIST_TYPE_COUNT),                                                       \
    ASCENDC_TPL_BOOL_SEL(IS_STATIC_TILING_API, 0),                                                                    \
    ASCENDC_TPL_UINT_SEL(A8W4_KERNEL_TEMPLATE, ASCENDC_TPL_UI_LIST, GROUPED_MATMUL_A8W4_KERNEL_TEMPLATE_NONE),        \
    ASCENDC_TPL_UINT_SEL(A16W8_KERNEL_TEMPLATE, ASCENDC_TPL_UI_LIST, GROUPED_MATMUL_A16W8_KERNEL_TEMPLATE_NONE),      \
    ASCENDC_TPL_UINT_SEL(AIV_AIC_RATIO, ASCENDC_TPL_UI_LIST, aiv_aic_ratio)

ASCENDC_TPL_ARGS_DECL(
  HyperMegaMoe,
  // feature map datatype
  ASCENDC_TPL_DTYPE_DECL(D_T_A, GMM_TPL_FLOAT, GMM_TPL_FLOAT16, GMM_TPL_BF16, GMM_TPL_INT8, GMM_TPL_INT4),
  // weight datatype
  ASCENDC_TPL_DTYPE_DECL(D_T_B, GMM_TPL_FLOAT, GMM_TPL_FLOAT16, GMM_TPL_BF16, GMM_TPL_INT8, GMM_TPL_INT4),
  // output datatype
  ASCENDC_TPL_DTYPE_DECL(D_T_Y, GMM_TPL_FLOAT, GMM_TPL_INT32, GMM_TPL_FLOAT16, GMM_TPL_BF16, GMM_TPL_INT8),
  // feature map transpose
  ASCENDC_TPL_BOOL_DECL(TRANS_A, 0, 1),
  // weight transpose
  ASCENDC_TPL_BOOL_DECL(TRANS_B, 0, 1),
  // group_list_type value
  ASCENDC_TPL_UINT_DECL(GROUP_LIST_TYPE, ASCENDC_TPL_2_BW, ASCENDC_TPL_UI_LIST, GROUPED_MATMUL_GROUP_LIST_TYPE_CUMSUM,
                        GROUPED_MATMUL_GROUP_LIST_TYPE_COUNT, GROUPED_MATMUL_GROUP_LIST_TYPE_SPARSEM),
  // use of matmul static tiling high-level api
  ASCENDC_TPL_BOOL_DECL(IS_STATIC_TILING_API, 0, 1),
  // kernel template in A8W4 scenario
  ASCENDC_TPL_UINT_DECL(
    A8W4_KERNEL_TEMPLATE, ASCENDC_TPL_4_BW, ASCENDC_TPL_UI_LIST,
    GROUPED_MATMUL_A8W4_KERNEL_TEMPLATE_NONE,                  // Not in A8W4 scenario
    GROUPED_MATMUL_A8W4_KERNEL_TEMPLATE_MSD_API_DEQUANT,       // MSD template, using API to dequant
    GROUPED_MATMUL_A8W4_KERNEL_TEMPLATE_MSD_VECTOR_DEQUANT,    // MSD template, using vector to dequant
    GROUPED_MATMUL_A8W4_KERNEL_TEMPLATE_PERCHANNEL_ANTIQUANT,  // Fake A8W8 template with perchannel quantization
    GROUPED_MATMUL_A8W4_KERNEL_TEMPLATE_PERGROUP_ANTIQUANT,    // Antiquant template without MSD strategy
    GROUPED_MATMUL_A8W4_KERNEL_TEMPLATE_AUTOTILING),           // Autotiling template with tuning config
  // kernel template in A16W8 scenario
  ASCENDC_TPL_UINT_DECL(A16W8_KERNEL_TEMPLATE, ASCENDC_TPL_2_BW, ASCENDC_TPL_UI_LIST,
                        GROUPED_MATMUL_A16W8_KERNEL_TEMPLATE_NONE,      // Not in A16W8 scenario
                        GROUPED_MATMUL_A16W8_KERNEL_TEMPLATE_MSD,       // A16W8 MSD template
                        GROUPED_MATMUL_A16W8_KERNEL_TEMPLATE_ANTIQUANT),  // A16W8 antiquant template
  // ratio of AIV:AIC
  ASCENDC_TPL_UINT_DECL(AIV_AIC_RATIO, ASCENDC_TPL_2_BW, ASCENDC_TPL_UI_LIST, GROUPED_MATMUL_CUBE_ONLY,
                        GROUPED_MATMUL_AIV_AIC_RATIO_1, GROUPED_MATMUL_AIV_AIC_RATIO_2));

ASCENDC_TPL_SEL(ASCENDC_TPL_ARGS_SEL(SET_GMM_NO_QUANT_TPL_ARGS(ASCENDC_TPL_MIX_AIC_1_2, GMM_TPL_BF16, 0, 0,
                                                               GROUPED_MATMUL_CUBE_ONLY)),
                ASCENDC_TPL_ARGS_SEL(SET_GMM_NO_QUANT_TPL_ARGS(ASCENDC_TPL_MIX_AIC_1_2, GMM_TPL_FLOAT16, 0, 0,
                                                               GROUPED_MATMUL_CUBE_ONLY)));

#endif  // HYPER_MEGA_MOE_TILING_KEY_H
