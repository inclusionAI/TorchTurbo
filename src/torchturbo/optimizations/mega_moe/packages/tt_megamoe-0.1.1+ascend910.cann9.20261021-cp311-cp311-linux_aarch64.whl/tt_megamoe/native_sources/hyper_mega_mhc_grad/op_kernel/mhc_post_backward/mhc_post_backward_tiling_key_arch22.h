/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */
/*!
 * \file mhc_post_backward_tiling_key.h
 * \brief mhc_post_backward tiling key declare
 */

#ifndef __MHC_POST_BACKWARD_TILING_KEY_ARCH22_H__
#define __MHC_POST_BACKWARD_TILING_KEY_ARCH22_H__

#include "ascendc/host_api/tiling/template_argument.h"

ASCENDC_TPL_ARGS_DECL(MhcPostBackward, ASCENDC_TPL_UINT_DECL(SCHMODE, 1, ASCENDC_TPL_UI_LIST, 0));

ASCENDC_TPL_SEL(ASCENDC_TPL_ARGS_SEL(ASCENDC_TPL_KERNEL_TYPE_SEL(ASCENDC_TPL_AIV_ONLY),
                                     ASCENDC_TPL_UINT_SEL(SCHMODE, ASCENDC_TPL_UI_LIST, 0),
                                     ASCENDC_TPL_TILING_STRUCT_SEL(MhcPostBackwardTilingDataArch22)));

#endif
