/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
 * This file is a part of the CANN Open Software.
 * Licensed under CANN Open Software License Agreement Version 1.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/**
 * @file worker_kernel.cpp
 * @brief MoE-FFN backward — op-specific compute kernels + KernelWorker specialization.
 */

#include <cstddef>

#include "kernel_operator.h"
#include "swi_glu/swi_glu.cpp"
#include "swi_glu_grad/swi_glu_grad.cpp"
#include "grouped_matmul/grouped_matmul.cpp"
#include "put_mem_signal/put_mem_signal_kernel.cpp"
#include "runtime/worker_kernel.h"

using namespace AscendC;

namespace MulticoreRuntime {

class KernelWorker : public KernelWorkerBase<KernelWorker> {
 public:
  // input_list layout for hyper_mega_moe_grad (backward):
  //   [30] = tiling params  [31] = all_event_counters  [32] = profile_buffer
  //   [25] = gmm_workspace  [26] = swi_glu_grad_workspace
  static constexpr uint32_t TILING_IDX = 30;
  static constexpr uint32_t EVENT_IDX = 31;
  static constexpr uint32_t PROFILE_IDX = 32;
  static constexpr uint32_t WORKSPACE_IDX = 25;
  static constexpr uint32_t SWIGLU_GRAD_WORKSPACE_IDX = 26;
  static constexpr uint32_t SWIGLU_DYNAMIC_FIELDS_OFFSET =
    static_cast<uint32_t>(offsetof(SwiGluTilingData, rowLen));
  static constexpr int64_t SWIGLU_DYNAMIC_FIELDS_BYTES =
    offsetof(SwiGluTilingData, baseRowLen) + sizeof(uint32_t) - SWIGLU_DYNAMIC_FIELDS_OFFSET;
  static constexpr uint32_t GMM_BASE_M_OFFSET = static_cast<uint32_t>(
    offsetof(GMMTilingData, gmmBaseParams) + offsetof(GMMBaseParams, m));
  static constexpr uint32_t GMM_MATMUL_M_OFFSET = static_cast<uint32_t>(
    offsetof(GMMTilingData, mmTilingData) + offsetof(TCubeTiling, M));
  static constexpr int64_t GMM_MATMUL_M_FIELDS_BYTES =
    offsetof(TCubeTiling, singleCoreM) + sizeof(int32_t) - offsetof(TCubeTiling, M);
  static constexpr uint32_t GMM_MATMUL_K_OFFSET = static_cast<uint32_t>(
    offsetof(GMMTilingData, mmTilingData) + offsetof(TCubeTiling, Ka));
  static constexpr int64_t GMM_MATMUL_K_FIELDS_BYTES =
    offsetof(TCubeTiling, singleCoreK) + sizeof(int32_t) - offsetof(TCubeTiling, Ka);

  __aicore__ inline void ExecuteComputeKernel(TaskDesc task_desc) {
    switch (task_desc.task_type) {
      case TaskType::TASK_BEGIN_TASK_GRAPH:
        break;
      case TaskType::TASK_MATMUL:
        ExecuteMatmul(task_desc);
        break;
      case TaskType::TASK_GROUPED_MATMUL:
        ExecuteGroupedMatmul(task_desc);
        break;
      case TaskType::TASK_SHMEM_PUT_MEM_SIGNAL:
        ExecuteShmemPutMem(task_desc);
        break;
      case TaskType::TASK_SHMEM_GET_MEM:
        ExecuteShmemGetMem<DTYPE_DISPATCH_TARGET>(task_desc);
        break;
      case TaskType::TASK_SWI_GLU_GRAD:
        ExecuteSwiGluGrad(task_desc);
        break;
      default:
        break;
    }
  }

 private:
  __aicore__ inline float GetSwiGluClampLimit(const TaskDesc &task_desc) {
    union {
      uint32_t bits;
      float value;
    } encoded = {};
    encoded.bits = task_desc.extra_value_0;
    return encoded.value;
  }

  __aicore__ inline bool getTransposeData(uint32_t data) { return data == 1; }

  __aicore__ inline void ExecuteMatmul(const TaskDesc &task_desc) {}

  __aicore__ inline void cacheWriteThrough(__gm__ uint8_t *sourceAddr, int64_t length) {
    if (length <= 0) {
      return;
    }
    __gm__ uint8_t *start =
      (__gm__ uint8_t *)((int64_t)sourceAddr / AscendC::CACHE_LINE_SIZE * AscendC::CACHE_LINE_SIZE);
    __gm__ uint8_t *end =
      (__gm__ uint8_t *)(((int64_t)sourceAddr + length - 1) / AscendC::CACHE_LINE_SIZE * AscendC::CACHE_LINE_SIZE);
    AscendC::GlobalTensor<uint8_t> global;
    global.SetGlobalBuffer(start);
    for (uint32_t i = 0; i <= end - start; i += AscendC::CACHE_LINE_SIZE) {
      __asm__ __volatile__("");
      AscendC::DataCacheCleanAndInvalid<uint8_t, AscendC::CacheLine::SINGLE_CACHE_LINE,
                                        AscendC::DcciDst::CACHELINE_OUT>(global[i]);
      __asm__ __volatile__("");
    }
  }

  __aicore__ inline void ExecuteSwiGluGrad(const TaskDesc &task_desc) {
    if (task_desc.extra_value_1 != 0x434F4D50) {
      ExecuteSwiGluGradLegacy(task_desc);
      return;
    }
    DynamicData data;
    getDynamicData(this->runtimeConfigPtr, &data);
    const uint32_t lanes = task_desc.task_split_num / data.dynamic_group_size;
    const uint32_t expert = task_desc.task_index / lanes;
    const uint32_t lane = task_desc.task_index % lanes;
    GlobalTensor<int64_t> groups;
    groups.SetGlobalBuffer(reinterpret_cast<__gm__ int64_t *>(input_list[data.dynamic_input_position]),
                           data.dynamic_group_size);
    const int64_t start = expert == 0 ? 0 : groups.GetValue(expert - 1);
    const int64_t rows = groups.GetValue(expert) - start;
    const uint32_t tiles = static_cast<uint32_t>((rows + task_desc.task_split_value - 1) /
                                                task_desc.task_split_value);
    const uint32_t legacy_tiles = tiles > 0 ? tiles : 1;
    TaskDesc tile = task_desc;
    tile.extra_value_1 = 0;
    tile.task_split_num = legacy_tiles * data.dynamic_group_size;
    for (uint32_t index = lane; index < tiles; index += lanes) {
      tile.task_index = expert * legacy_tiles + index;
      ExecuteSwiGluGradLegacy(tile);
    }
  }

  __aicore__ inline void ExecuteSwiGluGradLegacy(const TaskDesc &task_desc) {
    if (task_desc.inputs[0].dynamic_shape == 1 || task_desc.outputs[0].dynamic_shape == 1) {
      DynamicData dynamic_data;
      getDynamicData(this->runtimeConfigPtr, &(dynamic_data));
      if (dynamic_data.dynamic_type == DynamicType::DYNAMIC_DSV3_MOE) {
        GM_ADDR grouped_list = input_list[dynamic_data.dynamic_input_position];
        GlobalTensor<int64_t> grouped_list_tensor;
        int64_t ep = getExtraValueFromTiling(input_list[TILING_IDX], 1);
        int64_t expert_num = getExtraValueFromTiling(input_list[TILING_IDX], 2);
        int64_t expert_num_single_rank = expert_num / ep;
        grouped_list_tensor.SetGlobalBuffer((__gm__ int64_t *)(grouped_list), expert_num_single_rank);

        uint32_t grouped_list_shape = dynamic_data.dynamic_group_size;
        uint32_t per_task_num = task_desc.task_split_num / grouped_list_shape;
        uint32_t data_index = task_desc.task_index / per_task_num;
        uint32_t task_index = task_desc.task_index % per_task_num;
        int64_t start = 0;
        int64_t end = grouped_list_tensor.GetValue(data_index);
        if (data_index != 0) {
          start = grouped_list_tensor.GetValue(data_index - 1);
        }
        int64_t current_seq_start = task_index * task_desc.task_split_value;
        int64_t current_seq_end = (task_index + 1) * task_desc.task_split_value;
        int64_t base_ptr_offset = start + current_seq_start;

        if (base_ptr_offset >= end) {
          return;
        }
        int64_t input_0_offset = task_desc.inputs[0].dynamic_shape == 1
                                   ? base_ptr_offset * task_desc.inputs[0].dim[1] * task_desc.inputs[0].data_type
                                   : task_desc.inputs[0].base_ptr_offset * task_desc.inputs[0].data_type;
        int64_t input_1_offset = task_desc.inputs[1].dynamic_shape == 1
                                   ? base_ptr_offset * task_desc.inputs[1].dim[1] * task_desc.inputs[1].data_type
                                   : task_desc.inputs[1].base_ptr_offset * task_desc.inputs[1].data_type;
        int64_t output_0_offset = task_desc.outputs[0].dynamic_shape == 1
                                    ? base_ptr_offset * task_desc.outputs[0].dim[1] * task_desc.outputs[0].data_type
                                    : task_desc.outputs[0].base_ptr_offset * task_desc.outputs[0].data_type;
        if (start + current_seq_end <= end) {
          swi_glu_grad(input_list[task_desc.inputs[0].input_position] + input_0_offset,
                       input_list[task_desc.inputs[1].input_position] + input_1_offset,
                       input_list[task_desc.outputs[0].input_position] + output_0_offset,
                       input_list[SWIGLU_GRAD_WORKSPACE_IDX],
                       input_list[task_desc.tiling_data_position] + task_desc.tiling_data_offset,
                       GetSwiGluClampLimit(task_desc));
          return;
        } else {
          GM_ADDR tiling_data_addr = input_list[task_desc.tiling_data_position] + 80 * (AscendC::GetBlockIdx() + 1);
          __gm__ SwiGluTilingData *tilingdata_data = reinterpret_cast<__gm__ SwiGluTilingData *>(tiling_data_addr);
          tilingdata_data->rowLen = end - (start + current_seq_start);
          if (tilingdata_data->rowLen == 0) {
            return;
          }
          if (end - (start + current_seq_start) < SWIGLU_DYNAMIC_TAIL_BASE_ROW_LIMIT) {
            tilingdata_data->baseRowLen = end - (start + current_seq_start);
          }
          cacheWriteThrough(tiling_data_addr + SWIGLU_DYNAMIC_FIELDS_OFFSET, SWIGLU_DYNAMIC_FIELDS_BYTES);
          PipeBarrier<PIPE_ALL>();

          swi_glu_grad(input_list[task_desc.inputs[0].input_position] + input_0_offset,
                       input_list[task_desc.inputs[1].input_position] + input_1_offset,
                       input_list[task_desc.outputs[0].input_position] + output_0_offset,
                       input_list[SWIGLU_GRAD_WORKSPACE_IDX],
                       tiling_data_addr, GetSwiGluClampLimit(task_desc));
        }
      }
      return;
    }
  }

  __aicore__ inline void ExecuteGroupedMatmul(const TaskDesc &task_desc) {
    if (task_desc.inputs[0].dynamic_shape == 1 || task_desc.inputs[1].dynamic_shape == 1) {
      DynamicData dynamic_data;
      getDynamicData(this->runtimeConfigPtr, &(dynamic_data));
      if (dynamic_data.dynamic_type == DynamicType::DYNAMIC_DSV3_MOE) {
        GM_ADDR grouped_list = input_list[task_desc.inputs[2].input_position] +
                               task_desc.inputs[2].base_ptr_offset * task_desc.inputs[2].data_type;
        GlobalTensor<int64_t> grouped_list_tensor;
        int64_t ep = getExtraValueFromTiling(input_list[TILING_IDX], 1);
        int64_t expert_num = getExtraValueFromTiling(input_list[TILING_IDX], 2);
        int64_t expert_num_single_rank = expert_num / ep;
        grouped_list_tensor.SetGlobalBuffer((__gm__ int64_t *)(grouped_list), expert_num_single_rank);

        GM_ADDR grouped_list_real = this->runtimeConfigPtr + this->grouped_matmul_group_list_offset_;
        GlobalTensor<int64_t> grouped_list_tensor_real;
        grouped_list_tensor_real.SetGlobalBuffer((__gm__ int64_t *)(grouped_list_real), expert_num_single_rank);
        uint32_t data_index = task_desc.task_index / this->core_num;
        int64_t value = grouped_list_tensor.GetValue(data_index);
        int64_t start = 0;
        if (data_index != 0) {
          value = value - grouped_list_tensor.GetValue(data_index - 1);
          start = grouped_list_tensor.GetValue(data_index - 1);
        }
        if (value == 0) {
          return;
        }
        const bool single_group = (this->scheduler_flags_ & 4) != 0;
        if (single_group) {
          grouped_list_tensor_real.SetValue(0, value);
          cacheWriteThrough(grouped_list_real, sizeof(int64_t));
        } else {
          for (uint32_t i = 0; i < expert_num_single_rank; i++) {
            grouped_list_tensor_real.SetValue(i, i >= data_index ? value : 0);
          }
          cacheWriteThrough(grouped_list_real, expert_num_single_rank * sizeof(int64_t));
        }

        GM_ADDR tiling_data_addr = input_list[task_desc.tiling_data_position] + 2016 * AscendC::GetBlockIdx();
        __gm__ GMMTilingData *tilingdata_data = reinterpret_cast<__gm__ GMMTilingData *>(tiling_data_addr);
        if (getTransposeData(task_desc.inputs[0].transpose_flag)) {
          tilingdata_data->mmTilingData.Ka = value;
          tilingdata_data->mmTilingData.Kb = value;
          tilingdata_data->mmTilingData.singleCoreK = value;
          cacheWriteThrough(tiling_data_addr + GMM_MATMUL_K_OFFSET, GMM_MATMUL_K_FIELDS_BYTES);
        } else {
          tilingdata_data->gmmBaseParams.m = value;
          tilingdata_data->mmTilingData.M = value;
          tilingdata_data->mmTilingData.singleCoreM = value;
          cacheWriteThrough(tiling_data_addr + GMM_BASE_M_OFFSET, sizeof(uint32_t));
          cacheWriteThrough(tiling_data_addr + GMM_MATMUL_M_OFFSET, GMM_MATMUL_M_FIELDS_BYTES);
        }
        PipeBarrier<PIPE_ALL>();

        int64_t input_0_offset = task_desc.inputs[0].dynamic_shape == 1
                                   ? start * task_desc.inputs[0].dim[1] * task_desc.inputs[0].data_type
                                   : task_desc.inputs[0].base_ptr_offset * task_desc.inputs[0].data_type;
        int64_t input_1_offset = task_desc.inputs[1].dynamic_shape == 1
                                   ? start * task_desc.inputs[1].dim[1] * task_desc.inputs[1].data_type
                                   : task_desc.inputs[1].base_ptr_offset * task_desc.inputs[1].data_type;
        int64_t output_0_offset = task_desc.outputs[0].dynamic_shape == 1
                                    ? start * task_desc.outputs[0].dim[1] * task_desc.outputs[0].data_type
                                    : task_desc.outputs[0].base_ptr_offset * task_desc.outputs[0].data_type;

        if (single_group) {
          if (task_desc.inputs[1].dynamic_shape != 1) {
            input_1_offset = static_cast<int64_t>(data_index) * task_desc.inputs[1].dim[1] *
                             task_desc.inputs[1].dim[2] * task_desc.inputs[1].data_type;
          }
          if (task_desc.outputs[0].dynamic_shape != 1) {
            output_0_offset = static_cast<int64_t>(data_index) * task_desc.inputs[0].dim[1] *
                              task_desc.inputs[1].dim[1] * task_desc.outputs[0].data_type;
          }
        }
        grouped_matmul(input_list[task_desc.inputs[0].input_position] + input_0_offset,
                       input_list[task_desc.inputs[1].input_position] + input_1_offset, nullptr, nullptr, nullptr,
                       nullptr, nullptr, grouped_list_real, nullptr,
                       input_list[task_desc.outputs[0].input_position] + output_0_offset, input_list[WORKSPACE_IDX],
                       tiling_data_addr, getTransposeData(task_desc.inputs[0].transpose_flag),
                       getTransposeData(task_desc.inputs[1].transpose_flag));
      }
      return;
    }
  }

  __aicore__ inline void ExecuteShmemPutMem(const TaskDesc &task_desc) {
    GM_ADDR signal = input_list[EVENT_IDX];

    int64_t ep = getExtraValueFromTiling(input_list[TILING_IDX], 1);
    int64_t expert_num = getExtraValueFromTiling(input_list[TILING_IDX], 2);
    int64_t expert_num_single_rank = expert_num / ep;
    int64_t hidden_size = getExtraValueFromTiling(input_list[TILING_IDX], 3);

    int64_t rank_id = (*(__gm__ int64_t *)(input_list[TILING_IDX])) / ep * ep;
    int64_t single_expert_task_num = task_desc.task_split_num / expert_num;
    int64_t target_pe = rank_id + task_desc.task_index / (expert_num_single_rank * single_expert_task_num);

    int64_t target_offset_ = *((__gm__ int64_t *)(input_list[task_desc.inputs[0].input_position] +
                                                  task_desc.inputs[0].base_ptr_offset * task_desc.inputs[0].data_type));
    int64_t src_offset_ = *((__gm__ int64_t *)(input_list[task_desc.inputs[2].input_position] +
                                               task_desc.inputs[2].base_ptr_offset * task_desc.inputs[2].data_type));
    int32_t size_ = *((__gm__ int32_t *)(input_list[task_desc.inputs[3].input_position] +
                                         task_desc.inputs[3].base_ptr_offset * task_desc.inputs[3].data_type));
    int64_t partition_rows = task_desc.task_split_value;
    if (task_desc.extra_value_1 == 0x434F4D50) {
      const int64_t rows = static_cast<int64_t>(size_) / hidden_size;
      // Rows are contiguous and individually aligned by the BF16 hidden dimension.
      partition_rows = (rows + single_expert_task_num - 1) / single_expert_task_num;
    }
    int64_t send_data_size_ = partition_rows * hidden_size;
    const int64_t value = task_desc.task_index % single_expert_task_num;
    const int64_t start = value * partition_rows * hidden_size;
    const int64_t end = start + send_data_size_;
    if (start >= size_) {
      aclshmemx_signal_op(reinterpret_cast<__gm__ int32_t *>(signal) + task_desc.trigger_event, 1, ACLSHMEM_SIGNAL_ADD,
                          target_pe);
      return;
    } else {
      if (end > size_) {
        send_data_size_ = size_ - start;
      }
    }
    target_offset_ = target_offset_ + static_cast<int64_t>(start);
    src_offset_ = src_offset_ + static_cast<int64_t>(start);
    send_data_size_ = static_cast<int64_t>(send_data_size_);

    put_mem_signal_kernel(input_list[task_desc.outputs[0].input_position] +
                            task_desc.outputs[0].base_ptr_offset * task_desc.outputs[0].data_type,
                          target_offset_,
                          input_list[task_desc.inputs[1].input_position] +
                            task_desc.inputs[1].base_ptr_offset * task_desc.inputs[1].data_type,
                          src_offset_, send_data_size_, signal, static_cast<int64_t>(task_desc.trigger_event), 1,
                          nullptr, 1, target_pe, false);
  }
};

}  // namespace MulticoreRuntime

extern "C" inline __aicore__ void worker_kernel(uint32_t worker_id, __gm__ uint8_t *runtimeConfigPtr,
                                                GM_ADDR *input_list) {
  MulticoreRuntime::KernelWorker worker;
  worker.Init(worker_id, runtimeConfigPtr, input_list);
  worker.Process();
}
