# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================
"""
Backward pass: generate RuntimeConfig binary files and tiling binary files.

Usage:
    python gen_runtime_data.py [--tp 4] [--ep 4] [--seq_size 8192]
                               [--all_expert_num 32] [--top_k 8]
                               [--output_dir mega_moe_grad_tp4_ep4_910b]

Outputs (rank-independent):
    <output_dir>/act_grad_tiling.bin         (act_grad, pos 20)
    <output_dir>/gate_grad_tiling.bin        (gate_grad, pos 21)
    <output_dir>/w1_grad_tiling.bin          (w1_grad, pos 22)
    <output_dir>/w2_grad_tiling.bin          (w2_grad, pos 23)
    <output_dir>/swiglu_grad_tiling.bin      (SwiGLU-grad, pos 24)
    <output_dir>/all_event_counters.bin      graph-sized int32 zeros (at least 4 KB)
    <output_dir>/gmm_workspace.bin           256 MiB zeros

Outputs (per rank):
    <output_dir>/runtime_config_input_rank_<i>.bin
"""
import argparse
from dataclasses import dataclass
import os

from tt_megamoe.modules.mega_moe.backward.graph import (
    build_backward_graph,
)
from tt_megamoe.modules.mega_moe.backward.tiling_tables import (
    get_act_grad_tiling_bytes,
    get_gate_grad_tiling_bytes,
    get_swiglu_grad_tiling_bytes,
    get_w1_grad_tiling_bytes,
    get_w2_grad_tiling_bytes,
)
from tt_megamoe.modules.mega_moe.profiling import (
    _configure_mega_moe_profile_metadata,
)
from tt_megamoe.scheduler.builder import allocate_graph_config
from tt_megamoe.scheduler.config import (
    RuntimeConfigC,
    TaskSplitValue,
    configure_ready_handshake,
    event_workspace_bytes,
    init_task_split_value,
    validate_runtime_config,
)
from tt_megamoe.scheduler.graph import ComputeGraph
from tt_megamoe.scheduler.runtime import serialize_runtime_config
from tt_megamoe.scheduler.scheduler import (
    revise_gmm_task_queue_bwd,
    revise_task_queue,
)
from tt_megamoe.tasks.utils import add_dynamic_data, add_terminate


@dataclass(frozen=True)
class _GenerationContext:
    """Prepared arguments, topology and graph for backward data generation."""

    args: argparse.Namespace
    task_values: TaskSplitValue
    graph: ComputeGraph


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments for backward data generation."""
    p = argparse.ArgumentParser()
    p.add_argument('--tp',                type=int, default=4)
    p.add_argument('--ep',                type=int, default=4)
    p.add_argument('--seq_size',          type=int, default=8192)
    p.add_argument('--all_expert_num',    type=int, default=32)
    p.add_argument('--top_k',             type=int, default=8)
    p.add_argument('--hidden_size',       type=int, default=7168,
                   help='Model hidden dimension (e.g. 7168 for Qwen3-235B)')
    p.add_argument('--intermediate_size', type=int, default=2048,
                   help='FFN intermediate dimension after SwiGLU halving (half of up-proj output, e.g. 2048)')
    p.add_argument('--dtype_size',        type=int, default=2,
                   help='Activation bytes per element: bf16=2, fp32=4')
    p.add_argument('--num_cube_cores',    type=int, default=24,
                   help='Number of AI Cube cores on target hardware (910B=24)')
    p.add_argument('--output_dir',        type=str,
                   default='mega_moe_grad_tp4_ep4_910b')
    return p.parse_args()


def build_config_for_rank(graph: ComputeGraph, tsv: TaskSplitValue, rank_id: int,
                          num_cube_cores: int = 24) -> RuntimeConfigC:
    """Build backward RuntimeConfig for a single rank.

    Args:
        graph: Propagated backward compute graph.
        tsv: Task split values for the target topology.
        rank_id: Rank-local identifier.
        num_cube_cores: Available cube-core count.

    Returns:
        Validated runtime image including transport handshakes and profiler metadata.
    """
    cfg = allocate_graph_config(graph, tsv)
    cfg.num_workers    = 2 * num_cube_cores   # NUM_WORKERS_VECTOR = 2 × NUM_WORKERS_CUBE

    # Reset counters
    init_task_split_value(tsv)
    tsv.rank_id = rank_id

    # Fill tasks in topological order (dispatch, act_grad, w2_grad, swiglu_grad, gate_grad, combine, w1_grad)
    for op in graph.topological_sort():
        op.fill_config.fill(cfg, op, tsv)

    # task_num_all = sum of all op tasks + 1 (terminate)
    task_num_all = sum(op.task_num for op in graph.topological_sort()) + 1

    dispatch_op    = graph.get_op("dispatch")
    swiglu_grad_op = graph.get_op("swiglu_grad")
    act_grad_op    = graph.get_op("act_grad")
    w1_grad_op     = graph.get_op("w1_grad")
    w2_grad_op     = graph.get_op("w2_grad")
    combine_op     = graph.get_op("combine")

    add_terminate(cfg, tsv,
                  w2_grad_op.task_num + w1_grad_op.task_num
                  + combine_op.task_num // tsv.ep * tsv.ep)
    revise_task_queue(cfg, tsv, dispatch_op.task_num, swiglu_grad_op.task_num, combine_op.task_num)
    revise_gmm_task_queue_bwd(cfg, tsv, act_grad_op.task_num, num_cube_cores=num_cube_cores)
    add_dynamic_data(cfg, tsv, dynamic_input_position=19)

    cfg.task_num = task_num_all
    cfg.atomic_add_values[0] = 1
    configure_ready_handshake(cfg, tsv)
    validate_runtime_config(cfg, tsv, num_cube_cores)
    _configure_mega_moe_profile_metadata(
        cfg,
        graph,
        tsv,
        num_cube_cores=num_cube_cores,
        is_backward=True,
    )
    return cfg


def write_bin(path: str, data: bytes) -> None:
    """Write binary data to a file, creating parent directories if needed.

    Args:
        path: Destination file path.
        data: Serialized payload bytes.
    """
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path, 'wb') as f:
        f.write(data)
    print(f"  wrote {len(data):>10,} bytes → {path}")


def _prepare_generation(args: argparse.Namespace) -> _GenerationContext:
    """Build and propagate the backward graph from command-line arguments."""
    task_values = TaskSplitValue(
        tp=args.tp, ep=args.ep,
        seq_size=args.seq_size,
        all_expert_num=args.all_expert_num,
        top_k=args.top_k,
    )
    graph = build_backward_graph(task_values,
                                 dispatch_sv=128,  act_grad_sv=4096,  w2_grad_sv=4096,
                                 swiglu_sv=128,    gate_grad_sv=4096, w1_grad_sv=4096,
                                 combine_sv=128,
                                 hidden_size=args.hidden_size,
                                 intermediate_size=args.intermediate_size,
                                 dtype_size=args.dtype_size,
                                 num_cube_cores=args.num_cube_cores)
    graph.propagate_splits(task_values)
    return _GenerationContext(args, task_values, graph)


def _describe_graph(context: _GenerationContext) -> None:
    """Print the resolved backward task counts."""
    args = context.args
    graph = context.graph

    dispatch_op    = graph.get_op("dispatch")
    act_grad_op    = graph.get_op("act_grad")
    w2_grad_op     = graph.get_op("w2_grad")
    swiglu_grad_op = graph.get_op("swiglu_grad")
    gate_grad_op   = graph.get_op("gate_grad")
    w1_grad_op     = graph.get_op("w1_grad")
    combine_op     = graph.get_op("combine")

    print(f"[bwd] tp={args.tp} ep={args.ep} seq={args.seq_size} "
          f"E={args.all_expert_num} topk={args.top_k}")
    print(f"      dispatch={dispatch_op.task_num}  act_grad={act_grad_op.task_num}  "
          f"w2_grad={w2_grad_op.task_num}  swiglu_grad={swiglu_grad_op.task_num}  "
          f"gate_grad={gate_grad_op.task_num}  w1_grad={w1_grad_op.task_num}  "
          f"combine={combine_op.task_num}")


def _write_tiling_files(context: _GenerationContext) -> None:
    """Write all rank-independent backward tiling files."""
    args = context.args
    graph = context.graph
    num_groups = context.task_values.single_rank_expert_num
    act_grad_op = graph.get_op("act_grad")
    gate_grad_op = graph.get_op("gate_grad")
    w1_grad_op = graph.get_op("w1_grad")
    w2_grad_op = graph.get_op("w2_grad")
    swiglu_grad_op = graph.get_op("swiglu_grad")
    act_grad_bytes    = get_act_grad_tiling_bytes(act_grad_op.split_value,
                                                  hidden_size=args.hidden_size,
                                                  intermediate_size=args.intermediate_size,
                                                  num_groups=num_groups,
                                                  num_cube_cores=args.num_cube_cores)
    gate_grad_bytes   = get_gate_grad_tiling_bytes(gate_grad_op.split_value,
                                                   hidden_size=args.hidden_size,
                                                   intermediate_size=args.intermediate_size,
                                                   num_groups=num_groups,
                                                   num_cube_cores=args.num_cube_cores)
    w1_grad_bytes     = get_w1_grad_tiling_bytes(w1_grad_op.split_value,
                                                 hidden_size=args.hidden_size,
                                                 intermediate_size=args.intermediate_size,
                                                 num_groups=num_groups,
                                                 num_cube_cores=args.num_cube_cores)
    w2_grad_bytes     = get_w2_grad_tiling_bytes(w2_grad_op.split_value,
                                                 hidden_size=args.hidden_size,
                                                 intermediate_size=args.intermediate_size,
                                                 num_groups=num_groups,
                                                 num_cube_cores=args.num_cube_cores)
    swiglu_grad_bytes = get_swiglu_grad_tiling_bytes(swiglu_grad_op.split_value,
                                                     intermediate_size=args.intermediate_size)

    write_bin(os.path.join(args.output_dir, 'act_grad_tiling.bin'), act_grad_bytes)
    write_bin(os.path.join(args.output_dir, 'gate_grad_tiling.bin'), gate_grad_bytes)
    write_bin(os.path.join(args.output_dir, 'w1_grad_tiling.bin'), w1_grad_bytes)
    write_bin(os.path.join(args.output_dir, 'w2_grad_tiling.bin'), w2_grad_bytes)
    write_bin(os.path.join(args.output_dir, 'swiglu_grad_tiling.bin'), swiglu_grad_bytes)


def _write_common_buffers(context: _GenerationContext) -> None:
    """Write event-counter and GMM workspace payloads."""
    task_values = context.task_values
    output_dir = context.args.output_dir
    write_bin(os.path.join(output_dir, 'all_event_counters.bin'),
              bytes(event_workspace_bytes(task_values.ep, task_values.all_expert_num)))
    write_bin(os.path.join(output_dir, 'gmm_workspace.bin'),
              bytes(256 * 1024 * 1024))


def _write_runtime_configs(context: _GenerationContext) -> None:
    """Write one backward runtime configuration per EP rank."""
    args = context.args
    for rank_id in range(args.ep):
        cfg = build_config_for_rank(
            context.graph,
            context.task_values,
            rank_id,
            num_cube_cores=args.num_cube_cores,
        )
        data = serialize_runtime_config(cfg)
        path = os.path.join(args.output_dir, f'runtime_config_input_rank_{rank_id}.bin')
        write_bin(path, data)


def main() -> None:
    """Entry point for backward pass runtime data generation."""
    context = _prepare_generation(parse_args())
    _describe_graph(context)
    _write_tiling_files(context)
    _write_common_buffers(context)
    _write_runtime_configs(context)
    print("[bwd] done.")


if __name__ == '__main__':
    main()
