# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================
"""Model-facing Torch MegaMoe expert module."""

from __future__ import annotations

__all__ = ["MegaMoeExperts"]

import math
import os
import struct
from typing import Any

import torch
import torch.distributed as dist

from tt_megamoe import shmem
from tt_megamoe.activation import resolve_mode

from ..module import MulticoreModule
from .function import execute_mega_moe_with_permutation, _execute_mega_moe_without_autograd
from .plan import build_mega_moe_plan
from .route import prepare_topk_route, restore_topk_output
from .spec import (
    _COMMUNICATION_SPLIT, _grow_receive_capacity, _resolve_capacity_factors,
    _resolve_receive_capacity, bind_mega_moe_spec,
)
from .workspace import MegaMoeWorkspace, _spec_workspace_bytes


def _validate_swiglu_limit(swiglu_limit: float | None) -> None:
    """Validate a positive clamp value that survives float32 serialization."""
    if swiglu_limit is None:
        return
    valid_type = isinstance(swiglu_limit, (int, float)) and not isinstance(
        swiglu_limit, bool
    )
    try:
        encoded_limit = (
            struct.unpack("<f", struct.pack("<f", float(swiglu_limit)))[0]
            if valid_type
            else 0.0
        )
        valid_value = (
            valid_type
            and math.isfinite(swiglu_limit)
            and math.isfinite(encoded_limit)
            and encoded_limit > 0
        )
    except (OverflowError, TypeError, ValueError, struct.error):
        valid_value = False
    if not valid_value:
        raise ValueError(
            "swiglu_limit must be None or a finite positive float32-representable number, "
            f"got {swiglu_limit!r}."
        )


def _create_mega_moe_parameters(
    local_experts: int,
    hidden_size: int,
    intermediate_size: int,
) -> tuple[torch.nn.Parameter, torch.nn.Parameter]:
    """Create independently initialized local expert parameters."""
    gate_up_weight = torch.nn.Parameter(
        torch.empty((local_experts, hidden_size, intermediate_size * 2))
    )
    down_weight = torch.nn.Parameter(
        torch.empty((local_experts, intermediate_size, hidden_size))
    )
    for expert_index in range(local_experts):
        torch.nn.init.xavier_uniform_(gate_up_weight[expert_index])
        torch.nn.init.xavier_uniform_(down_weight[expert_index])
    return gate_up_weight, down_weight


def _heap_layout(specification: dict[str, Any], element_size: int, capacity: int | None = None) -> tuple[Any, ...]:
    """Describe byte demand and deterministic configuration with an opaque capacity payload."""
    if capacity is None:
        capacity = _resolve_receive_capacity(specification["initial_capacity_factor"],
                                             specification["local_num_tokens"] * specification["top_k"],
                                             specification["ep_size"])
    signature = tuple(sorted((key, value) for key, value in specification.items() if key != "ep_group"))
    return _spec_workspace_bytes(specification, element_size, receive_capacity=capacity), signature, capacity


class _MegaMoeExecutionResources:
    """Own one shape-bound plan and workspace in the shared SHMEM lifecycle."""

    def __init__(
        self,
        specification: dict[str, Any],
        tensor: torch.Tensor,
        *,
        shared: bool,
        active_specifications: tuple[Any, ...],
    ) -> None:
        """Bind resources once to the first NPU tensor."""
        self.spec = bind_mega_moe_spec(specification, tensor)
        self.specification = specification
        self.dtype, self.device, self.element_size = tensor.dtype, tensor.device, tensor.element_size()
        reservations = tuple((item, _heap_layout(item, self.element_size)) for item in active_specifications)
        self.heap_manager = shmem.get_heap_manager(
            self.spec.ep_group, tensor, reservations,
            allow_rebuild=any(item.get("dispatch_mode", "push") == "push" for item in active_specifications))
        shmem.acquire(self.spec.ep_group, heap_size_bytes=self.heap_manager.heap_bytes)
        try:
            self.plan = build_mega_moe_plan(self.spec, tensor.device)
            self.workspace = MegaMoeWorkspace(shared=shared)
            self.workspace.capacity_floor = self.heap_manager.bind(self, specification)
            self.workspace.heap_manager = self.heap_manager
            self._record_capacities()
        except Exception:
            shmem.release()
            raise
        self._closed = False
        self._workspace_closed = False

    def ensure_capacity(self, maximum_received_slots: int) -> None:
        """Submit a larger layout, falling back to minimum capacity within an explicit budget.

        Args:
            maximum_received_slots: Maximum destination load from the root count exchange.
        """
        if maximum_received_slots <= self.workspace.capacity_floor:
            return
        with self.heap_manager.access():
            capacity, minimum = _grow_receive_capacity(self.spec, self.workspace.capacity_floor, maximum_received_slots)
            layout = _heap_layout(self.specification, self.element_size, capacity)
            layouts = [layout if entry.resource is self else entry.layout for entry in self.heap_manager.entries]
            if (self.heap_manager.heap_limit is not None
                    and self.heap_manager.required_bytes(layouts) > self.heap_manager.heap_limit):
                layout = _heap_layout(self.specification, self.element_size, minimum)
            self.heap_manager.replace(self, layout)
            self._record_capacities()

    def _record_capacities(self) -> None:
        if self.heap_manager.growth_records and "capacities" not in self.heap_manager.growth_records[-1]:
            capacities = [entry.layout[2] for entry in self.heap_manager.entries]
            self.heap_manager.growth_records[-1]["capacities"] = capacities

    def heap_state(self) -> tuple[set[int], bool, bool]:
        """Expose workspace ownership to the root heap coordinator."""
        return self.workspace.heap_state()

    def release_heap(self) -> None:
        """Release physical buffers while retaining the workspace and graph leases."""
        self.workspace.close(for_rebuild=True)

    def restore_heap(self, capacity: int, allocated: bool) -> None:
        """Apply the new capacity and restore buffers only for previously allocated owners.

        Args:
            capacity: Target receive rows selected by the capacity policy.
            allocated: Whether this owner had physical buffers before the rebuild.
        """
        self.workspace.capacity_floor = capacity
        if allocated:
            self.workspace.ensure(self.spec, self.dtype, self.device)

    def lifecycle_signature(self) -> tuple[Any, ...]:
        """Identify allocations independently of process-local group addresses."""
        return (
            "mega_moe", self.spec.local_num_tokens, self.spec.hidden_size,
            self.spec.intermediate_size, self.spec.num_experts, self.spec.top_k,
            self.spec.receive_capacity, self.spec.ep_size, self.spec.dispatch_mode,
            self.spec.initial_capacity_factor, self.spec.capacity_growth_factor,
            self.spec.dispatch_split, self.spec.combine_split,
        )

    def can_close(self) -> bool:
        """Report whether neither an active call nor a backward graph needs buffers."""
        return self._workspace_closed or self.workspace.can_close()

    def close(self) -> None:
        """Release the workspace and leave the shared SHMEM lifecycle."""
        if self._closed:
            return
        with self.heap_manager.access():
            if not self._workspace_closed:
                self.workspace.close()
                self._workspace_closed = True
            shmem.release()
            self.heap_manager.remove(self)
            self._closed = True


class MegaMoeExperts(MulticoreModule):
    """Execute Router-selected local experts with the Torch MegaMoe kernel.

    Serial model layers can call :meth:`share_execution_resources` before
    their first forward to share one automatically growing workspace while keeping
    independent parameters and optimizer state.
    """

    def _resource_signature(self, tensor: Any) -> Any:
        """Compare static configuration without process-local group identities."""
        configuration = tuple(sorted((name, value) for name, value in self._resource_group.specification.items()
                                     if name != "ep_group"))
        return (super()._resource_signature(tensor), configuration,
                self._resource_group.shared)

    def _retain_runtime(self, manager: Any) -> None:
        """Pin SHMEM while the resource pool can replace orphan workspaces."""
        # Keep SHMEM initialized when replacing the last orphan with a new shape.
        manager.runtime_release = shmem.retain_runtime(self._ep_group)

    def __init__(
        self,
        *,
        local_num_tokens: int,
        hidden_size: int,
        intermediate_size: int,
        num_experts: int,
        top_k: int,
        swiglu_limit: float | None = None,
        swiglu_mode: str | None = None,
        ep_size: int = 1,
        ep_group: Any | None = None,
        create_parameters: bool = True,
        dispatch_mode: str = "push",
        initial_capacity_factor: float | None = None,
        capacity_growth_factor: float | None = None,
        dispatch_split: int = _COMMUNICATION_SPLIT,
        combine_split: int = _COMMUNICATION_SPLIT,
    ) -> None:
        """Initialize local expert parameters and a lazy execution owner.

        Args:
            local_num_tokens: Static token rows supplied to this rank.
            hidden_size: Input and output hidden dimension.
            intermediate_size: SwiGLU intermediate dimension per expert.
            num_experts: Global routed-expert count.
            top_k: Experts selected for every token.
            initial_capacity_factor: Push initial receive rows as a multiple of local routed rows.
                Defaults to 1.25 for push; omitted for pull. Must be finite and at least 1.0.
            capacity_growth_factor: Push capacity multiplier on overflow, defaulting to 1.25.
                Must be finite and at least 1.0; 1.0 grows only to the current route demand.
                The resulting capacity is capped by the lossless route bound. Pull rejects explicit factors.
            dispatch_mode: Dispatch transport, either "push" (default) or "pull".
                Construct separate modules to switch modes; sharing requires equal modes.
            dispatch_split: Dispatch tile rows in forward and backward, default 128.
                Must be a positive multiple of 128 that divides local_num_tokens.
            combine_split: Combine tile rows in forward and backward, with the same
                constraints and default as dispatch_split. Sharing requires equal splits.
            swiglu_limit: Optional positive, finite float32-representable clamp
                limit for SwiGLU. swiglu_mode selects clipping before or after
                SiLU; the up branch is clamped to ``[-limit, limit]``. ``None``
                preserves the legacy unclamped path.
            swiglu_mode: none, pre_activation, or post_activation. When omitted,
                choose none without a limit and post_activation with a limit.
            ep_size: Expert-parallel degree, equal to the size of ep_group.
            create_parameters: Allocate owned weights; False requires explicit expert_weights each forward.
            ep_group: Torch expert-parallel process group, possibly a subgroup of
                WORLD. Expert ownership follows group-local rank order. Disjoint
                PP/DP groups bootstrap independently; one process can have only
                one ordered EP membership active in SHMEM at a time.
        """
        if swiglu_limit is not None:
            _validate_swiglu_limit(swiglu_limit)
            # Clamp scalars follow the BF16 activation dtype, including equality.
            swiglu_limit = float(torch.tensor(swiglu_limit, dtype=torch.bfloat16))
        swiglu_mode = resolve_mode(swiglu_mode, swiglu_limit)
        specification = {
            "local_num_tokens": local_num_tokens,
            "hidden_size": hidden_size,
            "intermediate_size": intermediate_size,
            "num_experts": num_experts,
            "top_k": top_k,
            "initial_capacity_factor": initial_capacity_factor,
            "swiglu_limit": swiglu_limit,
            "swiglu_mode": swiglu_mode,
            "ep_size": ep_size,
            "ep_group": ep_group,
            "dispatch_mode": dispatch_mode,
            "capacity_growth_factor": capacity_growth_factor,
            "dispatch_split": dispatch_split,
            "combine_split": combine_split,
        }
        specification = self._resolve_specification(specification)
        compatibility_key = tuple(
            id(value) if name == "ep_group" else value for name, value in specification.items())
        super().__init__(
            resource_specification=specification,
            resource_compatibility_key=compatibility_key,
            resource_scope_key=("mega_moe", shmem.root_members(ep_group) if dist.is_initialized() else id(ep_group)),
        )
        self.local_num_tokens = local_num_tokens
        self.hidden_size = hidden_size
        self.intermediate_size = intermediate_size
        self.num_experts = num_experts
        self.top_k = top_k
        self.initial_capacity_factor = specification["initial_capacity_factor"]
        self.capacity_growth_factor = specification["capacity_growth_factor"]
        self.dispatch_mode = dispatch_mode
        self.dispatch_split = dispatch_split
        self.combine_split = combine_split
        self.swiglu_limit = specification["swiglu_limit"]
        self.swiglu_mode = specification["swiglu_mode"]
        self.ep_size = ep_size
        self.local_experts = num_experts // ep_size
        self._ep_group = ep_group
        if create_parameters:
            self.gate_up_weight, self.down_weight = _create_mega_moe_parameters(
                self.local_experts, hidden_size, intermediate_size,
            )
        else:
            self.register_parameter("gate_up_weight", None)
            self.register_parameter("down_weight", None)

    @classmethod
    def _resolve_specification(cls, specification: dict[str, Any]) -> dict[str, Any]:
        """Validate and normalize configuration before registering an execution owner."""
        initial_capacity_factor, capacity_growth_factor = _resolve_capacity_factors(
            specification["dispatch_mode"],
            specification["initial_capacity_factor"],
            specification["capacity_growth_factor"],
        )
        cls._validate_topology(
            local_num_tokens=specification["local_num_tokens"],
            hidden_size=specification["hidden_size"],
            intermediate_size=specification["intermediate_size"],
            num_experts=specification["num_experts"],
            top_k=specification["top_k"],
            swiglu_limit=specification["swiglu_limit"],
            ep_size=specification["ep_size"],
            dispatch_split=specification["dispatch_split"],
            combine_split=specification["combine_split"],
        )
        swiglu_limit = specification["swiglu_limit"]
        return {
            **specification,
            "initial_capacity_factor": initial_capacity_factor,
            "capacity_growth_factor": capacity_growth_factor,
            "swiglu_limit": float(swiglu_limit) if swiglu_limit is not None else None,
        }

    @staticmethod
    def _validate_topology(
        *,
        local_num_tokens: int,
        hidden_size: int,
        intermediate_size: int,
        num_experts: int,
        top_k: int,
        swiglu_limit: float | None,
        ep_size: int,
        dispatch_split: int,
        combine_split: int,
    ) -> None:
        """Validate static shape and topology values before allocation."""
        values = {
            "local_num_tokens": local_num_tokens,
            "hidden_size": hidden_size,
            "intermediate_size": intermediate_size,
            "num_experts": num_experts,
            "top_k": top_k,
            "ep_size": ep_size,
        }
        for name, value in values.items():
            if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
                raise ValueError(f"{name} must be a positive integer, got {value!r}.")
        if top_k > num_experts:
            raise ValueError(
                f"top_k ({top_k}) cannot exceed num_experts ({num_experts})."
            )
        if num_experts % ep_size:
            raise ValueError(
                f"num_experts ({num_experts}) must be divisible by ep_size ({ep_size})."
            )
        _validate_swiglu_limit(swiglu_limit)
        for name, split in (("dispatch_split", dispatch_split), ("combine_split", combine_split)):
            if (not isinstance(split, int) or isinstance(split, bool)
                    or split <= 0 or split % _COMMUNICATION_SPLIT):
                raise ValueError(
                    f"{name} must be a positive integer multiple of {_COMMUNICATION_SPLIT}, got {split!r}.")
            if local_num_tokens % split:
                raise ValueError(f"local_num_tokens ({local_num_tokens}) must be divisible by {name} ({split}).")

    def _root_group(self) -> Any:
        """Keep lifecycle coordination within this module's EP group."""
        return self._ep_group

    def _validate_tensors(self, hidden_states: torch.Tensor, expert_weights: tuple) -> None:
        """Validate activation and parameter metadata before acquiring resources."""
        if hidden_states.dtype != torch.bfloat16 or not hidden_states.is_npu:
            raise TypeError("MegaMoeExperts requires BF16 NPU hidden states.")
        weight1, weight2 = expert_weights
        if weight1 is None or weight2 is None:
            raise ValueError("Parameterless MegaMoe requires explicit expert_weights")
        expected_weight1 = (
            self.local_experts,
            self.hidden_size,
            self.intermediate_size * 2,
        )
        expected_weight2 = (
            self.local_experts,
            self.intermediate_size,
            self.hidden_size,
        )
        if tuple(weight1.shape) != expected_weight1:
            raise ValueError(
                f"gate_up_weight must have shape {expected_weight1}, got {tuple(weight1.shape)}."
            )
        if tuple(weight2.shape) != expected_weight2:
            raise ValueError(
                f"down_weight must have shape {expected_weight2}, got {tuple(weight2.shape)}."
            )
        if (
            weight1.device != hidden_states.device
            or weight2.device != hidden_states.device
        ):
            raise ValueError(
                "expert weights and hidden states must be on the same NPU."
            )
        if weight1.dtype != hidden_states.dtype or weight2.dtype != hidden_states.dtype:
            raise TypeError("expert weights and hidden states must all use BF16.")

    def _validate_forward_inputs(
        self,
        hidden_states: torch.Tensor,
        topk_ids: torch.Tensor,
        topk_weights: torch.Tensor,
        tokens_per_expert: torch.Tensor | None,
        expert_weights: tuple,
    ) -> torch.Tensor:
        """Validate input shapes and return flattened local token states."""
        if hidden_states.ndim < 2 or hidden_states.shape[-1] != self.hidden_size:
            raise ValueError(
                "hidden_states must have at least two dimensions and configured "
                f"hidden size {self.hidden_size}, got {tuple(hidden_states.shape)}."
            )
        hidden_flat = hidden_states.reshape(-1, self.hidden_size)
        if hidden_flat.shape[0] != self.local_num_tokens:
            raise ValueError(
                f"MegaMoeExperts expects {self.local_num_tokens} local tokens, "
                f"got {hidden_flat.shape[0]}."
            )
        route_shape = (self.local_num_tokens, self.top_k)
        if tuple(topk_ids.shape) != route_shape:
            raise ValueError(
                f"topk_ids must have shape {route_shape}, got {tuple(topk_ids.shape)}."
            )
        if tuple(topk_weights.shape) != route_shape:
            raise ValueError(
                f"topk_weights must have shape {route_shape}, "
                f"got {tuple(topk_weights.shape)}."
            )
        if tokens_per_expert is not None and tuple(tokens_per_expert.shape) != (
            self.num_experts,
        ):
            raise ValueError(
                f"tokens_per_expert must have shape ({self.num_experts},), "
                f"got {tuple(tokens_per_expert.shape)}."
            )
        self._validate_tensors(hidden_flat, expert_weights)
        return hidden_flat

    def forward(
        self,
        hidden_states: torch.Tensor,
        topk_ids: torch.Tensor,
        topk_weights: torch.Tensor,
        *,
        tokens_per_expert: torch.Tensor | None = None,
        expert_weights: tuple[torch.Tensor, torch.Tensor] | None = None,
    ) -> torch.Tensor:
        """Route token states through the configured experts.

        Args:
            hidden_states: Tensor ending in ``hidden_size``.
            topk_ids: Global expert IDs shaped ``[local_num_tokens, top_k]``.
            topk_weights: Router weights with the same shape as ``topk_ids``.
            expert_weights: Current unsharded weights owned by an outer module; noncontiguous
                layouts are copied with autograd tracking, never cached by this executor.
            tokens_per_expert: Optional trusted exact global-expert histogram.
                Supplying Router-produced counts skips histogram recomputation.

        Returns:
            Tensor matching the shape and dtype of ``hidden_states``.

        Note:
            ``tokens_per_expert`` must describe the current ``topk_ids`` exactly.
            The steady-state path validates metadata but deliberately does not
            rebuild and compare the histogram.
        """
        weights = ((self.gate_up_weight, self.down_weight) if expert_weights is None else expert_weights)
        hidden_flat = self._validate_forward_inputs(
            hidden_states,
            topk_ids,
            topk_weights,
            tokens_per_expert,
            weights,
        )
        if self.dispatch_mode == "push" and torch.npu.is_current_stream_capturing():
            raise RuntimeError("MegaMoe push heap growth does not support graph capture")
        resources = self._get_execution_resources(hidden_flat)
        pull = self.dispatch_mode == "pull"
        if pull:
            resources.workspace.ensure(resources.spec, hidden_flat.dtype, hidden_flat.device)
            resources.workspace.claim()
        try:
            # Pull writes its permutation into SHMEM, so its lease must cover
            # route preparation as well as execution and output restoration.
            with torch.no_grad():
                route = prepare_topk_route(
                    hidden_flat,
                    topk_ids,
                    topk_weights,
                    resources.spec,
                    tokens_per_expert,
                    workspace=resources.workspace,
                )
            if not pull:
                resources.ensure_capacity(route.maximum_received_slots)
            if not torch.is_grad_enabled():
                return _execute_mega_moe_without_autograd(
                    topk_weights, weights[0], weights[1], route, resources.plan,
                    resources.workspace, workspace_claimed=pull,
                ).reshape_as(hidden_states)
            expert_output = execute_mega_moe_with_permutation(
                hidden_flat,
                topk_ids,
                weights[0],
                weights[1],
                route,
                resources.plan,
                resources.workspace,
                topk_weights=topk_weights if pull else None,
                workspace_claimed=pull,
            )
        finally:
            if pull:
                resources.workspace.release()
        if pull:
            return expert_output.reshape_as(hidden_states)
        output = restore_topk_output(
            expert_output,
            route.unpermute_mapping,
            topk_weights,
        )
        return output.reshape(hidden_states.shape)

    def _create_execution_resources(
        self,
        tensor: torch.Tensor,
        *,
        shared: bool,
        active_specifications: tuple[Any, ...],
    ) -> _MegaMoeExecutionResources:
        """Create the plan and workspace owned by this resource group."""
        return _MegaMoeExecutionResources(
            self._resource_group.specification,
            tensor,
            shared=shared,
            active_specifications=active_specifications,
        )
